# Merge Rules

## Evidence ranking

1. Direct X post or clearly attributable first-person transcript
2. Repeated idea across multiple interviews or threads
3. Mirrored X content
4. Third-party summary or quote aggregator

## Primary voice

- `Michael_Liu93` controls:
  - final structure
  - regime framing
  - decision priority
  - confidence weighting

## Augmentation

- `gas1618` supplements:
  - market-maker and exchange incentive framing
  - paired-trade and hedge logic
  - caution around crowd extraction and staged rotation
  - dissent when consensus looks crowded or mechanically trapped

## Conflict handling

- If both imply the same direction:
  - produce one thesis and strengthen confidence

- If `Michael_Liu93` is constructive but `gas1618` sees extraction risk:
  - keep the main thesis constructive
  - lower confidence
  - surface `gas1618` dissent under `dissent`
  - prefer staggered entry, hedge, or wait-for-trigger framing

- If evidence is weak for both:
  - output `no trade` or `wait`
  - do not force exact price levels or sizing

## Current working conflict example

- `Michael_Liu93` tendency:
  - willing to engage narrative-rich sectors if flow, product, and market fit align

- `gas1618` tendency:
  - expects rotation games, extraction, and attention sequencing; prefers hedge expression when setup quality is mixed

- Final merged behavior:
  - thesis can stay constructive on the narrative
  - trigger must require flow confirmation
  - risk section must explain rotation and extraction risk
  - dissent must say when a hedge or no-trade expression is cleaner than naked long exposure
