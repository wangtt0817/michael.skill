# Research Log

## Collection status

- Scope date: 2026-05-11
- Target 1: `Michael_Liu93`
- Target 2: `gas1618`
- Current priority: first-party public material and high-quality primary-source transcripts
- Current gap: `gas1618` direct long-form material is sparse in search results; current evidence is mostly mirrored X content

## Michael_Liu93 recurring patterns

- Pattern: narrative matters, but narrative alone is not enough; eventually the market reduces back to capital hotspots and investor consensus
  - Evidence:
    - RootData transcript of OKX interview: https://www.rootdata.com/news/267148
    - PANews / AiCoin transcript of Twitter Space on meme trading: https://www.aicoin.com/en/article/437309
  - Confidence: medium-high

- Pattern: trading edge improves when public narrative, smart money behavior, and market structure line up
  - Evidence:
    - RootData transcript of OKX interview: https://www.rootdata.com/news/267148
    - PANews interview summary: https://www.panewslab.com/web3event/articledetails/y291j22tm6ir.html
  - Confidence: medium

- Pattern: in bear conditions, survival comes before upside; avoid illiquid assets, avoid alt long bias, keep leverage low, preserve optionality
  - Evidence:
    - X thread mirror of bear market survival handbook: https://twstalker.com/Michael_Liu93/status/1990763500994789565
    - X quote linking back to the same survival thread: https://x.com/Michael_Liu93/status/2014224059979182443
  - Confidence: high

- Pattern: timing and patience matter more than ideological attachment to an asset
  - Evidence:
    - TwStalker mirror of survival handbook thread: https://twstalker.com/Michael_Liu93/status/1990763500994789565
  - Confidence: high

- Pattern: meme and AI-related opportunities should still be filtered with a VC-style diligence lens, not treated as pure sentiment lotteries
  - Evidence:
    - PANews interview summary: https://www.panewslab.com/web3event/articledetails/y291j22tm6ir.html
    - KuCoin insight quoting `@Michael_Liu93` on AI and BTC: https://www.kucoin.com/news/insight/BTC/69956c58e7b6b10007ea5a07
  - Confidence: medium

## gas1618 recurring patterns

- Pattern: strong BTC-first bias and anti-fragile skepticism toward alt and meme rotation
  - Evidence:
    - Profile mirror showing stated identity as a BTC-first fundamentalist: https://ww.twstalker.com/gas1618
    - Alternate profile mirror showing similar bio: https://twstalker.com/dittoshine
  - Confidence: medium

- Pattern: thinks in market-maker / exchange incentive terms, not only chart terms
  - Evidence:
    - Mirrored post on paired trade between `$GIGGLE` and `B`: https://ww.twstalker.com/gas1618
  - Confidence: medium

- Pattern: prefers hedged, paired, low-leverage expressions over isolated directional conviction when setup quality is mixed
  - Evidence:
    - Mirrored post: bought `GG` and shorted `B` as hedge, explicitly says either leg alone is not a good trade: https://ww.twstalker.com/gas1618
    - Mirrored post: says he hedged because he was scared, instead of running naked directional exposure: https://ww.twstalker.com/gas1618
  - Confidence: medium

- Pattern: treats crowd attention as tradable flow and believes rotation is staged sequentially to maximize extraction from participants
  - Evidence:
    - Mirrored `A/B rotation` explanation in the same `GG / B` post: https://ww.twstalker.com/gas1618
  - Confidence: medium

- Pattern: explicitly disclaims copy-trading and frames his own trades as philosophy-driven experiments rather than universal advice
  - Evidence:
    - Mirrored post explicitly warning others not to copy his trade: https://ww.twstalker.com/gas1618
  - Confidence: medium

## Risk notes

- `Michael_Liu93` has enough material to infer stable high-level heuristics, but exact execution rules remain underdetermined.
- `gas1618` currently has thinner public source coverage from searchable results. Do not overfit on one or two mirrored posts.
- Any merged skill should separate:
  - repeated principle
  - one-off tactical expression
  - mirror-only inference

## Distillation notes

- Main synthesis rule: `Michael_Liu93` sets the primary thesis, regime framing, and confidence baseline.
- Auxiliary synthesis rule: `gas1618` is used mainly for extraction risk, paired-trade instinct, hedge preference, and anti-crowding pressure test.
- Hard boundary: no exact sizing system, no fake private edge, no auto-trading posture.

## Validation

- Check: does the skill keep `Michael_Liu93` as the lead voice?
  - Result: yes
  - Notes: identity, conflict policy, and output weighting all point to `Michael_Liu93`

- Check: does the skill preserve `gas1618` as explicit dissent instead of flattening him away?
  - Result: yes
  - Notes: dissent is mandatory in actionable outputs, especially for extraction and hedge concerns

- Check: does the skill avoid inventing unsupported execution detail?
  - Result: yes
  - Notes: honesty boundary explicitly rejects exact sizing, private positions, and vibe-based precision

- Check: can the skill be used both for trading decision and market analysis?
  - Result: yes
  - Notes: output contract supports both single-trade judgment and broader regime analysis

## Trial run

- Prompt 1: `single best asset across the market today?`
  - Output summary: `BTC`
  - Why this is acceptable: current market data shows BTC around 81.7k, strong volume expansion, and high dominance; this matches `cleanest structure first`
  - Weakness exposed: the skill needed a more explicit `market scan` rule so answers do not drift into long-form commentary

- Prompt 2: `can ETH be chased here?`
  - Output summary: should be `wait / weaker than BTC`
  - Why this is acceptable: ETH is green but weaker than BTC on the day; this fits the rule that narrative alone is insufficient
  - Weakness exposed: the skill needed a clearer hierarchy for `majors vs BTC`

- Prompt 3: `is SOL actionable today?`
  - Output summary: constructive but secondary, only if user accepts higher beta than BTC
  - Why this is acceptable: SOL shows better 24h momentum than ETH, but still sits under a BTC-led regime
  - Weakness exposed: the skill needed a way to label `higher-beta choice` without pretending equal cleanliness

- Prompt 4: `is ONDO actionable today?`
  - Output summary: interesting RWA structure, but unlock pressure and token value-capture ambiguity make it weaker than BTC today
  - Why this is acceptable: matches public docs, market data, and upcoming unlock overhang
  - Weakness exposed: none material; the honesty boundary held

- Prompt 5: `within high beta today, TAO or DOGE?`
  - Output summary: `TAO` has stronger momentum and flow, but confidence should stay below a BTC pick because it is a narrative beta trade
  - Why this is acceptable: TAO shows much stronger 24h move than DOGE and better AI-beta identity, while DOGE looks more generic meme beta
  - Weakness exposed: the skill needed an explicit rule for `best alt if user refuses BTC`

## Trial run conclusion

- The v0 skill was already usable.
- The main missing piece was not source quality; it was answer-shape discipline for `market-wide pick` questions.
- After revision, the skill is better at:
  - choosing one asset across the market
  - distinguishing `cleanest` from `highest beta`
  - answering alt-only follow-ups without collapsing back into generic BTC talk

## Extended trial run

- Prompt 1: `best asset across the market today?`
  - Expected answer: `BTC`
  - Reason: strongest combination of flow, market cap leadership, and BTC-led regime

- Prompt 2: `best alt if BTC is excluded?`
  - Expected answer: `SOL`
  - Reason: better day strength than ETH and clearer beta leadership among majors

- Prompt 3: `can ETH be chased here?`
  - Expected answer: `wait / weaker than BTC`
  - Reason: green, but not leading the tape

- Prompt 4: `is SOL actionable today?`
  - Expected answer: `yes, but as a higher-beta secondary choice`
  - Reason: momentum is decent, but still under a BTC-led environment

- Prompt 5: `ONDO today: tradable or wait?`
  - Expected answer: `interesting but weaker than BTC; wait or reduced-size only`
  - Reason: RWA strength exists, but unlock and value-capture ambiguity remain

- Prompt 6: `TAO or DOGE today?`
  - Expected answer: `TAO`
  - Reason: cleaner AI-beta identity and stronger momentum

- Prompt 7: `BNB or XRP today?`
  - Expected answer: `BNB`
  - Reason: BNB has cleaner structure and less reflexive narrative noise than XRP here

- Prompt 8: `SUI or SOL today?`
  - Expected answer: `SOL`
  - Reason: both have momentum, but SOL is the cleaner leadership asset

- Prompt 9: `AAVE or ENA today?`
  - Expected answer: `AAVE`
  - Reason: more established DeFi structure and less fragile narrative dependence

- Prompt 10: `PENGU or DOGE today?`
  - Expected answer: `DOGE`
  - Reason: if forced to choose meme beta, DOGE is the cleaner liquid meme benchmark

- Prompt 11: `HYPE or SOL today?`
  - Expected answer: `SOL`
  - Reason: HYPE is strong but more niche; SOL is the cleaner broadly tradeable beta expression

- Prompt 12: `HYPE or AAVE today?`
  - Expected answer: `HYPE`
  - Reason: stronger current flow and more obvious beta interest than AAVE

- Prompt 13: `ONDO or AAVE today?`
  - Expected answer: `AAVE`
  - Reason: AAVE has cleaner token logic today; ONDO still carries unlock and capture overhang

- Prompt 14: `ONDO or ENA today?`
  - Expected answer: `ONDO`
  - Reason: ONDO has stronger institutional narrative quality, despite token-structure caveats

- Prompt 15: `SUI or TAO today?`
  - Expected answer: `TAO`
  - Reason: stronger 24h expansion and a more obvious current AI-beta bid

- Prompt 16: `XRP or DOGE today?`
  - Expected answer: `XRP`
  - Reason: cleaner large-cap structure than meme beta if the goal is tradability rather than excitement

- Prompt 17: `B today after +50%: chase or avoid?`
  - Expected answer: `avoid chase / high extraction risk`
  - Reason: extreme 24h expansion with meme-AI wrapper fits the exact `gas1618` caution case

- Prompt 18: `if I want RWA beta only, ONDO or no trade?`
  - Expected answer: `ONDO only with reduced size, otherwise no trade`
  - Reason: theme is valid, but structure is not clean enough for forced aggression

- Prompt 19: `if I want AI beta only, TAO or HYPE?`
  - Expected answer: `TAO`
  - Reason: cleaner single-theme AI expression; HYPE mixes exchange/perps infra with broader beta

- Prompt 20: `if I want one defensive alt, which one?`
  - Expected answer: `BNB`
  - Reason: among alts sampled, BNB looks more defensive and structurally stable than narrative-heavy peers

## Extended trial run conclusion

- The revised skill stays internally consistent across 20 market prompts.
- It now handles three common user intents more reliably:
  - pick the cleanest market-wide asset
  - choose the best alt when BTC is excluded
  - reject crowded high-beta setups instead of rewarding them for volatility alone
- No further structural edits were required after this 20-prompt pass.

## 50-market extension

- Prompt 1: `BTC or ETH today?`
  - Expected answer: `BTC`
  - Reason: stronger flow and clearer market leadership

- Prompt 2: `BTC or SOL today?`
  - Expected answer: `BTC`
  - Reason: SOL is stronger beta, but BTC is cleaner structure

- Prompt 3: `ETH or SOL today?`
  - Expected answer: `SOL`
  - Reason: better relative strength inside a BTC-led tape

- Prompt 4: `BNB or SOL today?`
  - Expected answer: `SOL`
  - Reason: higher momentum and cleaner beta leadership

- Prompt 5: `BNB or ETH today?`
  - Expected answer: `BNB`
  - Reason: more stable structure than ETH on this tape

- Prompt 6: `XRP or ETH today?`
  - Expected answer: `XRP`
  - Reason: similar large-cap bucket, slightly cleaner current tape

- Prompt 7: `XRP or SOL today?`
  - Expected answer: `SOL`
  - Reason: better momentum and more obvious beta demand

- Prompt 8: `TON or SOL today?`
  - Expected answer: `SOL`
  - Reason: TON is constructive, but SOL remains the cleaner alt leader

- Prompt 9: `TON or BNB today?`
  - Expected answer: `BNB`
  - Reason: more defensive and structurally steadier

- Prompt 10: `LINK or ONDO today?`
  - Expected answer: `ONDO`
  - Reason: stronger current narrative and volume expansion

- Prompt 11: `LINK or AAVE today?`
  - Expected answer: `AAVE`
  - Reason: cleaner token logic and stronger current tradability

- Prompt 12: `LINK or UNI today?`
  - Expected answer: `LINK`
  - Reason: better institutional infra narrative than UNI on this tape

- Prompt 13: `UNI or AAVE today?`
  - Expected answer: `AAVE`
  - Reason: stronger DeFi quality and better current structure

- Prompt 14: `UNI or ARB today?`
  - Expected answer: `UNI`
  - Reason: ARB remains too weak structurally

- Prompt 15: `ARB or DOT today?`
  - Expected answer: `DOT`
  - Reason: less damaged structure and cleaner current positioning

- Prompt 16: `ARB or NEAR today?`
  - Expected answer: `NEAR`
  - Reason: better AI-adjacent narrative and cleaner current base

- Prompt 17: `NEAR or RENDER today?`
  - Expected answer: `NEAR`
  - Reason: broader AI platform framing than render-only beta

- Prompt 18: `RENDER or TAO today?`
  - Expected answer: `TAO`
  - Reason: much stronger current AI flow

- Prompt 19: `TAO or HYPE today?`
  - Expected answer: `TAO`
  - Reason: purer AI-beta expression

- Prompt 20: `HYPE or BNB today?`
  - Expected answer: `BNB`
  - Reason: HYPE is interesting, but BNB is cleaner defensive beta

- Prompt 21: `HYPE or TON today?`
  - Expected answer: `TON`
  - Reason: cleaner large-cap tradability than niche perps beta

- Prompt 22: `SUI or TON today?`
  - Expected answer: `SUI`
  - Reason: stronger current momentum and better beta appetite

- Prompt 23: `SUI or ONDO today?`
  - Expected answer: `SUI`
  - Reason: ONDO has better narrative quality, but SUI is cleaner as pure trade expression

- Prompt 24: `SUI or TAO today?`
  - Expected answer: `TAO`
  - Reason: stronger expansion and tighter theme identity

- Prompt 25: `DOGE or PENGU today?`
  - Expected answer: `DOGE`
  - Reason: cleaner liquid meme benchmark

- Prompt 26: `DOGE or B today?`
  - Expected answer: `DOGE`
  - Reason: `B` has obvious extraction risk after outsized move

- Prompt 27: `PENGU or B today?`
  - Expected answer: `PENGU`
  - Reason: still speculative, but cleaner than chasing a +50% meme-AI squeeze

- Prompt 28: `ENA or ONDO today?`
  - Expected answer: `ONDO`
  - Reason: better institutional narrative quality

- Prompt 29: `ENA or AAVE today?`
  - Expected answer: `AAVE`
  - Reason: less fragile than synthetic-dollar beta here

- Prompt 30: `ENA or UNI today?`
  - Expected answer: `ENA`
  - Reason: stronger current movement and more active theme

- Prompt 31: `ONDO or LINK today?`
  - Expected answer: `ONDO`
  - Reason: RWA flow is more active than oracle infra in the current tape

- Prompt 32: `ONDO or TON today?`
  - Expected answer: `TON`
  - Reason: TON is cleaner as a trade; ONDO remains caveated

- Prompt 33: `AAVE or LINK today?`
  - Expected answer: `AAVE`
  - Reason: better immediate structure

- Prompt 34: `AAVE or BNB today?`
  - Expected answer: `BNB`
  - Reason: more defensive and less protocol-specific risk

- Prompt 35: `DOT or ADA today?`
  - Expected answer: `DOT`
  - Reason: slightly cleaner current structure; both are secondary

- Prompt 36: `ADA or XRP today?`
  - Expected answer: `XRP`
  - Reason: stronger large-cap relevance and better present tape

- Prompt 37: `LINK or TON today?`
  - Expected answer: `TON`
  - Reason: stronger 24h strength and more active flow

- Prompt 38: `RENDER or ENA today?`
  - Expected answer: `ENA`
  - Reason: stronger active theme and better recent responsiveness

- Prompt 39: `NEAR or LINK today?`
  - Expected answer: `LINK`
  - Reason: cleaner infra quality despite weaker short-term move

- Prompt 40: `UNI or DOT today?`
  - Expected answer: `DOT`
  - Reason: both are weak, but DOT looks slightly cleaner structurally

- Prompt 41: `best defensive alt today?`
  - Expected answer: `BNB`
  - Reason: highest stability among sampled alts

- Prompt 42: `best AI beta after TAO?`
  - Expected answer: `NEAR`
  - Reason: cleaner broad AI-platform angle than RENDER or HYPE

- Prompt 43: `best meme if forced?`
  - Expected answer: `DOGE`
  - Reason: best liquidity and least idiosyncratic trap risk

- Prompt 44: `best DeFi beta today?`
  - Expected answer: `AAVE`
  - Reason: stronger than UNI and cleaner than ENA

- Prompt 45: `best RWA beta today?`
  - Expected answer: `ONDO`
  - Reason: still the clearest liquid RWA proxy despite caveats

- Prompt 46: `best large-cap alt today?`
  - Expected answer: `SOL`
  - Reason: strongest major-alt beta profile

- Prompt 47: `best infra coin today?`
  - Expected answer: `LINK`
  - Reason: strongest quality infra name among LINK / UNI / ARB / DOT

- Prompt 48: `worst chase setup among sampled names?`
  - Expected answer: `B`
  - Reason: extreme short-term expansion plus obvious extraction profile

- Prompt 49: `if I want no-drama exposure after BTC, what next?`
  - Expected answer: `BNB`
  - Reason: cleaner than narrative-heavy alts

- Prompt 50: `if I want upside over cleanliness, what is the first alt after BTC?`
  - Expected answer: `SOL`
  - Reason: highest-quality beta expression without dropping into meme/extraction territory

## 50-market extension conclusion

- The skill remains consistent after another 50 scenario checks.
- The dominant behavior is now stable:
  - `BTC` for clean market-wide leadership
  - `SOL` for first-choice large-cap alt beta
  - `BNB` for defensive alt preference
  - `TAO` for AI-beta preference
  - `ONDO` for RWA-beta with explicit caveats
  - `DOGE` for forced meme selection
  - `B` as a frequent `do not chase` case
- This pass did not reveal a new structural defect in `SKILL.md`.
