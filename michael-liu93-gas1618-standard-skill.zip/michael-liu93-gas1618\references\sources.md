# Sources

## Michael_Liu93

- Type: interview transcript
  - URL: https://www.rootdata.com/news/267148
  - Why it matters: contains first-person framing on transition from tradfi to crypto, meme evaluation, and the shift from chasing smart money to understanding narrative, hotspots, and consensus
  - Confidence: direct transcript published by RootData summarizing OKX interview

- Type: event/article transcript
  - URL: https://www.panewslab.com/web3event/articledetails/y291j22tm6ir.html
  - Why it matters: supports repeated themes on meme valuation, VC-style diligence, and how he thinks about information gaps and market structure
  - Confidence: medium-high transcript / event summary

- Type: interview transcript mirror
  - URL: https://www.aicoin.com/en/article/437309
  - Why it matters: overlaps with other interview material and helps confirm that some themes are repeated rather than one-off
  - Confidence: medium transcript mirror

- Type: X thread mirror
  - URL: https://twstalker.com/Michael_Liu93/status/1990763500994789565
  - Why it matters: strong direct evidence for bear-market operating rules, patience, liquidity awareness, and low-leverage bias
  - Confidence: medium direct-content mirror

- Type: X quote post
  - URL: https://x.com/Michael_Liu93/status/2014224059979182443
  - Why it matters: directly references and endorses the survival handbook as recurring advice, not a one-time comment
  - Confidence: direct

- Type: quote aggregator
  - URL: https://www.kucoin.com/news/insight/BTC/69956c58e7b6b10007ea5a07
  - Why it matters: evidence of AI and agent-economy framing entering his market view
  - Confidence: low-medium aggregator quote

## gas1618

- Type: X profile mirror
  - URL: https://ww.twstalker.com/gas1618
  - Why it matters: direct statement of self-positioning around macro research, divination framing, BTC-first ideology, and lived loss history
  - Confidence: medium direct-content mirror

- Type: alternate profile mirror
  - URL: https://twstalker.com/dittoshine
  - Why it matters: confirms broad identity traits remain stable across mirror snapshots even if follower counts and wording drift
  - Confidence: low-medium indirect mirror reference

- Type: mirrored X thread
  - URL: https://ww.twstalker.com/gas1618
  - Why it matters: contains the `GG / B` paired-trade logic, an `A/B rotation` framework, market-maker incentive framing, and explicit low-leverage preference
  - Confidence: medium direct-content mirror

- Type: mirrored X post
  - URL: https://ww.twstalker.com/gas1618
  - Why it matters: explicit hedge-first behavior with `buy GG / short paired leg`, plus explicit anti-copy-trade disclaimer
  - Confidence: medium direct-content mirror

- Type: mirrored reply
  - URL: https://www.twstalker.com/0xfengxun/status/1950752929541132402
  - Why it matters: small but useful signal that he compresses market thinking into reflexive symmetry phrases about success and reversal
  - Confidence: low one-line mirror

## Source quality rule

- Prefer direct X URLs when accessible
- Use transcript sources when they preserve first-person statements
- Treat mirrors and aggregators as supporting evidence, not sole authority
